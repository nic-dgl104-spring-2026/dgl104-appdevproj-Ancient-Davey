package com.example.taskmanagementsystem.patterns.observer

class TaskSubject {

    private val observers = mutableListOf<TaskObserver>()

    fun addObserver(observer: TaskObserver) {

        observers.add(observer)

    }

    fun removeObserver(observer: TaskObserver) {

        observers.remove(observer)

    }

    fun notifyObservers(message: String) {

        observers.forEach {

            it.onTaskChanged(message)

        }

    }

}
