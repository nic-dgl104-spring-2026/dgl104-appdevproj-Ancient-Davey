package com.example.taskmanagementsystem.patterns.observer

interface TaskObserver {

    fun onTaskChanged(message: String)

}