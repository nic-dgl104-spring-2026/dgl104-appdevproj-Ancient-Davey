package com.example.taskmanagementsystem.patterns.observer

import android.content.Context
import android.widget.Toast

class NotificationObserver(

    private val context: Context

) : TaskObserver {

    override fun onTaskChanged(message: String) {

        Toast.makeText(

            context,

            message,

            Toast.LENGTH_SHORT

        ).show()

    }

}