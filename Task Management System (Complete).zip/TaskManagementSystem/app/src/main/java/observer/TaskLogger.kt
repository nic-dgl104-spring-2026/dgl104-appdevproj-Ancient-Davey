package com.example.taskmanagementsystem.patterns.observer

import android.util.Log

class TaskLogger : TaskObserver {

    override fun onTaskChanged(message: String) {

        Log.d("TaskObserver", message)

    }

}