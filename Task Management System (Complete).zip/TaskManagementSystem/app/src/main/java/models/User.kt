package com.example.taskmanagementsystem.models

open class User(
    var name: String = "",
    var email: String = "",
    var role: String = ""
)