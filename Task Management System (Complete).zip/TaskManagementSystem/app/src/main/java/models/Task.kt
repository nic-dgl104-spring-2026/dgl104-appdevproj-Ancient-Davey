package com.example.taskmanagementsystem.models
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
@Parcelize
data class Task(

    var id: String = "",
    var title: String = "",
    var description: String = "",
    var priority: String = "",
    var status: String = "",
    var dueDate: String = "",
    var assignedTo: String = ""

) : Parcelable