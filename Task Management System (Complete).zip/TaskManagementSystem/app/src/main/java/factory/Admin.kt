package com.example.taskmanagementsystem.patterns.factory

class Admin(

    override val name: String,

    override val email: String

) : BaseUser(

    name,

    email,

    "Admin"

)