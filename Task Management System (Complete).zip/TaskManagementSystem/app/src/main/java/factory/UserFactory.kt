package com.example.taskmanagementsystem.patterns.factory

object UserFactory {

    fun createUser(

        role: String,

        name: String,

        email: String

    ): BaseUser {

        return when (role) {

            "Admin" -> Admin(

                name,

                email

            )

            "Manager" -> Manager(

                name,

                email

            )

            "Tester" -> Tester(

                name,

                email

            )

            else -> Developer(

                name,

                email

            )

        }

    }

}