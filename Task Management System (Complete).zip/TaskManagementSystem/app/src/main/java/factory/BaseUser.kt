package com.example.taskmanagementsystem.patterns.factory

open class BaseUser(

    open val name: String,

    open val email: String,

    open val role: String

)
