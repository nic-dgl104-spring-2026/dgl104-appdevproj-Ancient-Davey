package com.example.taskmanagementsystem.patterns.factory

class Manager(

    override val name: String,

    override val email: String

) : BaseUser(

    name,

    email,

    "Manager"

)