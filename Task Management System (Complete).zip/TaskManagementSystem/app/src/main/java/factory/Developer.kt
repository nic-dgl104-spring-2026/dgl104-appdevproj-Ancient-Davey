package com.example.taskmanagementsystem.patterns.factory

class Developer(

    override val name: String,

    override val email: String

) : BaseUser(

    name,

    email,

    "Developer"

)