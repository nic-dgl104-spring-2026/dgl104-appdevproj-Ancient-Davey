package com.example.taskmanagementsystem.patterns.factory

class Tester(

    override val name: String,

    override val email: String

) : BaseUser(

    name,

    email,

    "Tester"

)