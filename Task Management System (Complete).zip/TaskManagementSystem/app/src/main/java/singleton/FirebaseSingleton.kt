package com.example.taskmanagementsystem.singleton

import com.google.firebase.firestore.FirebaseFirestore

object FirebaseSingleton {

    val database: FirebaseFirestore by lazy {
        FirebaseFirestore.getInstance()
    }

}