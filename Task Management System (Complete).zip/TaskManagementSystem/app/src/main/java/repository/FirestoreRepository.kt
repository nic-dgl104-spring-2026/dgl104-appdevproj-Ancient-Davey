package com.example.taskmanagementsystem.repository

import android.util.Log
import com.example.taskmanagementsystem.models.Task
import com.example.taskmanagementsystem.patterns.observer.TaskObserver
import com.example.taskmanagementsystem.patterns.observer.TaskSubject
import com.example.taskmanagementsystem.singleton.FirebaseSingleton


class FirestoreRepository {

    private val subject = TaskSubject()

    private val db = FirebaseSingleton.database

    fun addObserver(observer: TaskObserver) {
        subject.addObserver(observer)
    }

    // CREATE TASK
    fun addTask(
        task: Task,
        onSuccess: (() -> Unit)? = null,
        onFailure: ((Exception) -> Unit)? = null
    ) {

        val document = db.collection("tasks").document()

        val newTask = task.copy(id = document.id)

        document.set(newTask)
            .addOnSuccessListener {

                Log.d("Firestore", "Task created")

                subject.notifyObservers("Task Created")

                onSuccess?.invoke()

            }
            .addOnFailureListener { exception ->

                Log.e("Firestore", "Create failed", exception)

                onFailure?.invoke(exception)

            }

    }

    // READ TASKS
    fun getTasks(callback: (List<Task>) -> Unit) {

        db.collection("tasks")
            .get()
            .addOnSuccessListener { result ->

                val tasks = result.documents.mapNotNull { document ->

                    document.toObject(Task::class.java)?.copy(
                        id = document.id
                    )

                }

                callback(tasks)

            }
            .addOnFailureListener { exception ->

                Log.e("Firestore", "Read failed", exception)

                callback(emptyList())

            }

    }

    // UPDATE TASK
    fun updateTask(
        task: Task,
        onSuccess: (() -> Unit)? = null,
        onFailure: ((Exception) -> Unit)? = null
    ) {

        if (task.id.isBlank()) {
            onFailure?.invoke(Exception("Task ID is empty"))
            return
        }

        db.collection("tasks")
            .document(task.id)
            .set(task)
            .addOnSuccessListener {

                Log.d("Firestore", "Task updated")

                subject.notifyObservers("Task Updated")

                onSuccess?.invoke()

            }
            .addOnFailureListener { exception ->

                Log.e("Firestore", "Update failed", exception)

                onFailure?.invoke(exception)

            }
    }

    fun deleteTask(
        id: String,
        onSuccess: (() -> Unit)? = null,
        onFailure: ((Exception) -> Unit)? = null
    ) {

        Log.d("Firestore", "Deleting task with id: $id")

        db.collection("tasks")
            .document(id)
            .delete()
            .addOnSuccessListener {

                Log.d("Firestore", "Task deleted")

                subject.notifyObservers("Task Deleted")

                onSuccess?.invoke()

            }
            .addOnFailureListener { exception ->

                Log.e("Firestore", "Delete failed", exception)

                onFailure?.invoke(exception)

            }
    }
}