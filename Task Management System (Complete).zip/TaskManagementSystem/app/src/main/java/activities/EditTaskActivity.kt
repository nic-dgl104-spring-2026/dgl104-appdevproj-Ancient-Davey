package com.example.taskmanagementsystem.activities

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.taskmanagementsystem.R
import com.example.taskmanagementsystem.models.Task
import com.example.taskmanagementsystem.repository.FirestoreRepository
import java.util.Calendar

class EditTaskActivity : AppCompatActivity() {

    private val repository = FirestoreRepository()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_edit_task)

        val task = intent.getParcelableExtra("task", Task::class.java)

        if (task == null) {

            Toast.makeText(
                this,
                "Task not found",
                Toast.LENGTH_SHORT
            ).show()

            finish()
            return
        }

        val titleInput = findViewById<EditText>(R.id.titleInput)
        val descriptionInput = findViewById<EditText>(R.id.descriptionInput)
        val prioritySpinner = findViewById<Spinner>(R.id.prioritySpinner)
        val statusSpinner = findViewById<Spinner>(R.id.statusSpinner)
        val dueDateText = findViewById<TextView>(R.id.dueDateText)
        val selectDateButton = findViewById<Button>(R.id.selectDateButton)
        val updateButton = findViewById<Button>(R.id.updateButton)

        val priorities = arrayOf("Low", "Medium", "High")
        val statuses = arrayOf("To Do", "In Progress", "Completed")

        prioritySpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            priorities
        )

        statusSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            statuses
        )

        titleInput.setText(task.title)
        descriptionInput.setText(task.description)

        prioritySpinner.setSelection(
            priorities.indexOf(task.priority)
        )

        statusSpinner.setSelection(
            statuses.indexOf(task.status)
        )

        var selectedDate = task.dueDate

        dueDateText.text = selectedDate

        selectDateButton.setOnClickListener {

            val calendar = Calendar.getInstance()

            DatePickerDialog(

                this,

                { _, year, month, day ->

                    selectedDate = "$day/${month + 1}/$year"

                    dueDateText.text = selectedDate

                },

                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)

            ).show()

        }

        updateButton.setOnClickListener {

            if (titleInput.text.toString().trim().isEmpty()) {

                titleInput.error = "Enter a title"
                return@setOnClickListener

            }

            if (descriptionInput.text.toString().trim().isEmpty()) {

                descriptionInput.error = "Enter a description"
                return@setOnClickListener

            }

            if (selectedDate.isEmpty()) {

                Toast.makeText(
                    this,
                    "Please select a due date",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener

            }

            val updatedTask = task.copy(

                title = titleInput.text.toString().trim(),

                description = descriptionInput.text.toString().trim(),

                priority = prioritySpinner.selectedItem.toString(),

                status = statusSpinner.selectedItem.toString(),

                dueDate = selectedDate

            )

            repository.updateTask(

                updatedTask,

                onSuccess = {

                    Toast.makeText(
                        this,
                        "Task Updated",
                        Toast.LENGTH_SHORT
                    ).show()

                    finish()

                },

                onFailure = {

                    Toast.makeText(
                        this,
                        it.message,
                        Toast.LENGTH_LONG
                    ).show()

                }

            )

        }

    }

}