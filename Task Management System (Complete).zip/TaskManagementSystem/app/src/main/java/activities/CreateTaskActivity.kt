package com.example.taskmanagementsystem.activities

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.taskmanagementsystem.R
import com.example.taskmanagementsystem.models.Task
import com.example.taskmanagementsystem.repository.FirestoreRepository
import java.util.Calendar

class CreateTaskActivity : AppCompatActivity() {

    private val repository = FirestoreRepository()

    private lateinit var titleInput: EditText
    private lateinit var descriptionInput: EditText
    private lateinit var prioritySpinner: Spinner
    private lateinit var dueDateText: TextView
    private lateinit var selectDateButton: Button
    private lateinit var saveButton: Button

    private lateinit var assignInput: EditText

    private var selectedDate = ""

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_task)

        // Find Views
        titleInput = findViewById(R.id.titleInput)
        descriptionInput = findViewById(R.id.descriptionInput)
        assignInput = findViewById(R.id.assignInput)
        prioritySpinner = findViewById(R.id.prioritySpinner)
        dueDateText = findViewById(R.id.dueDateText)
        selectDateButton = findViewById(R.id.selectDateButton)
        saveButton = findViewById(R.id.saveButton)

        // Priority Spinner
        val priorities = arrayOf("Low", "Medium", "High")

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            priorities
        )

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        prioritySpinner.adapter = adapter

        // Date Picker
        selectDateButton.setOnClickListener {

            val calendar = Calendar.getInstance()

            DatePickerDialog(

                this,

                { _, year, month, day ->

                    selectedDate = "$day/${month + 1}/$year"

                    dueDateText.text = selectedDate

                },

                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)

            ).show()

        }

        // Save Task
        saveButton.setOnClickListener {

            val title = titleInput.text.toString().trim()
            val description = descriptionInput.text.toString().trim()
            val assignedTo = assignInput.text.toString().trim()
            val priority = prioritySpinner.selectedItem.toString()

            if (title.isEmpty()) {

                titleInput.error = "Please enter a task title"
                titleInput.requestFocus()
                return@setOnClickListener

            }

            if (description.isEmpty()) {

                descriptionInput.error = "Please enter a description"
                descriptionInput.requestFocus()
                return@setOnClickListener

            }

            if (assignedTo.isEmpty()) {

                assignInput.error = "Please enter who the task is assigned to"
                assignInput.requestFocus()
                return@setOnClickListener

            }

            if (selectedDate.isEmpty()) {

                Toast.makeText(
                    this,
                    "Please select a due date",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener

            }

            val task = Task(

                title = title,

                description = description,

                priority = priority,

                status = "To Do",

                dueDate = selectedDate,

                assignedTo = assignedTo

            )

            repository.addTask(

                task,

                onSuccess = {

                    android.util.Log.d("CREATE_TASK", "SUCCESS CALLBACK REACHED")

                    Toast.makeText(
                        this,
                        "Task Added Successfully",
                        Toast.LENGTH_SHORT
                    ).show()

                    finish()

                },

                onFailure = { exception ->

                    android.util.Log.e(
                        "CREATE_TASK",
                        "FAILED",
                        exception
                    )

                    Toast.makeText(
                        this,
                        exception.message ?: "Unknown error",
                        Toast.LENGTH_LONG
                    ).show()

                }


            )

        }

    }

}