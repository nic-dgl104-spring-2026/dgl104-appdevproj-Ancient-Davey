package com.example.taskmanagementsystem.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.taskmanagementsystem.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        val nameInput = findViewById<EditText>(R.id.nameInput)
        val emailInput = findViewById<EditText>(R.id.emailInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val registerButton = findViewById<Button>(R.id.registerButton)

        registerButton.setOnClickListener {

            val name = nameInput.text.toString().trim()
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()

            // Name Validation
            if (name.isEmpty()) {

                nameInput.error = "Please enter your name"
                nameInput.requestFocus()
                return@setOnClickListener

            }

            // Email Validation
            if (email.isEmpty()) {

                emailInput.error = "Please enter your email"
                emailInput.requestFocus()
                return@setOnClickListener

            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {

                emailInput.error = "Please enter a valid email"
                emailInput.requestFocus()
                return@setOnClickListener

            }

            // Password Validation
            if (password.isEmpty()) {

                passwordInput.error = "Please enter a password"
                passwordInput.requestFocus()
                return@setOnClickListener

            }

            if (password.length < 6) {

                passwordInput.error = "Password must be at least 6 characters"
                passwordInput.requestFocus()
                return@setOnClickListener

            }



            // Create Firebase Account
            auth.createUserWithEmailAndPassword(email, password)

                .addOnSuccessListener {

                    val user = auth.currentUser

                    if (user == null) {

                        Toast.makeText(
                            this,
                            "Unable to create account.",
                            Toast.LENGTH_SHORT
                        ).show()

                        return@addOnSuccessListener

                    }

                    val userData = hashMapOf(

                        "uid" to user.uid,

                        "name" to name,

                        "email" to email,

                        "role" to "Developer"

                    )

                    firestore.collection("users")
                        .document(user.uid)
                        .set(userData)

                        .addOnSuccessListener {

                            Log.d(
                                "RegisterActivity",
                                "User registered successfully"
                            )

                            Toast.makeText(
                                this,
                                "Account Created Successfully.\nPlease log in.",
                                Toast.LENGTH_SHORT
                            ).show()

                            // Sign the user out so they must log in
                            auth.signOut()

                            // Go to Login screen
                            val intent = Intent(
                                this,
                                LoginActivity::class.java
                            )

                            // Remove RegisterActivity from the back stack
                            intent.flags =
                                Intent.FLAG_ACTIVITY_NEW_TASK or
                                        Intent.FLAG_ACTIVITY_CLEAR_TASK

                            startActivity(intent)

                            finish()

                        }

                        .addOnFailureListener { exception ->

                            Log.e(
                                "RegisterActivity",
                                "Firestore Error",
                                exception
                            )

                            Toast.makeText(
                                this,
                                exception.message,
                                Toast.LENGTH_LONG
                            ).show()

                        }

                }

                .addOnFailureListener { exception ->

                    Log.e(
                        "RegisterActivity",
                        "Registration Failed",
                        exception
                    )

                    Toast.makeText(
                        this,
                        exception.message,
                        Toast.LENGTH_LONG
                    ).show()

                }

        }

    }

}