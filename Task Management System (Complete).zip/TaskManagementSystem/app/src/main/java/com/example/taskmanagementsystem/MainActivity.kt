package com.example.taskmanagementsystem.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.taskmanagementsystem.R
import com.example.taskmanagementsystem.adapters.TaskAdapter
import com.example.taskmanagementsystem.models.Task
import com.example.taskmanagementsystem.patterns.observer.NotificationObserver
import com.example.taskmanagementsystem.patterns.observer.TaskLogger
import com.example.taskmanagementsystem.repository.FirestoreRepository
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: TaskAdapter

    private val taskList = mutableListOf<Task>()

    private val repository = FirestoreRepository()

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        repository.addObserver(NotificationObserver(this))
        repository.addObserver(TaskLogger())

        recyclerView = findViewById(R.id.taskRecyclerView)

        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = TaskAdapter(

            taskList,

            onEdit = { task ->

                val intent =
                    Intent(this, EditTaskActivity::class.java)

                intent.putExtra("task", task)

                startActivity(intent)

            },

            onDelete = { task ->

                AlertDialog.Builder(this)

                    .setTitle("Delete Task")

                    .setMessage("Delete this task?")

                    .setPositiveButton("Yes") { _, _ ->

                        Toast.makeText(
                            this,
                            "Deleting ID: ${task.id}",
                            Toast.LENGTH_LONG
                        ).show()

                        repository.deleteTask(

                            task.id,

                            onSuccess = {

                                Toast.makeText(
                                    this,
                                    "Task Deleted",
                                    Toast.LENGTH_SHORT
                                ).show()

                                taskList.remove(task)

                                adapter.notifyDataSetChanged()

                            },

                            onFailure = {

                                Toast.makeText(
                                    this,
                                    it.message,
                                    Toast.LENGTH_LONG
                                ).show()

                            }

                        )

                    }

                    .setNegativeButton("Cancel", null)

                    .show()

            }

        )

        recyclerView.adapter = adapter

        findViewById<FloatingActionButton>(R.id.addTaskButton)
            .setOnClickListener {

                startActivity(

                    Intent(
                        this,
                        CreateTaskActivity::class.java
                    )

                )

            }

    }

    override fun onResume() {

        super.onResume()

        loadTasks()

    }

    private fun loadTasks() {

        repository.getTasks { tasks ->

            taskList.clear()

            taskList.addAll(tasks)

            adapter.notifyDataSetChanged()

        }

    }

}