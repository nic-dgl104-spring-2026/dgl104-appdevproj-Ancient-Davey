package strategy

import com.example.taskmanagementsystem.strategy.DeadlinePriority
import org.junit.Assert
import org.junit.Test

class PriorityStrategyTest {

    @Test
    fun highPriorityTest() {

        val strategy = DeadlinePriority()

        Assert.assertEquals("High", strategy.calculatePriority(1))

    }

    @Test
    fun mediumPriorityTest() {

        val strategy = DeadlinePriority()

        Assert.assertEquals("Medium", strategy.calculatePriority(5))

    }

    @Test
    fun lowPriorityTest() {

        val strategy = DeadlinePriority()

        Assert.assertEquals("Low", strategy.calculatePriority(15))

    }

}