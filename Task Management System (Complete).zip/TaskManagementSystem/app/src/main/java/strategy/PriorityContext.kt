package com.example.taskmanagementsystem.strategy

import strategy.PriorityStrategy

class PriorityContext(
    private var strategy: PriorityStrategy
) {

    fun setStrategy(strategy: PriorityStrategy) {
        this.strategy = strategy
    }

    fun getPriority(daysLeft: Int): String {
        return strategy.calculatePriority(daysLeft)
    }

}