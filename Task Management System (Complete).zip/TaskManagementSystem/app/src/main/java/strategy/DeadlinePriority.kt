package com.example.taskmanagementsystem.strategy

import strategy.PriorityStrategy


class DeadlinePriority:
    PriorityStrategy {


    override fun calculatePriority(
        daysLeft:Int
    ):String {


        return when {
            daysLeft <= 2 -> "High"
            daysLeft <= 7 -> "Medium"
            else -> "Low"
        }

    }

}