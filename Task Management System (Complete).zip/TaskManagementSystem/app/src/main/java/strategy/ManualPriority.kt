package com.example.taskmanagementsystem.strategy

import strategy.PriorityStrategy

class ManualPriority : PriorityStrategy {

    override fun calculatePriority(daysLeft: Int): String {
        return "Manual"
    }

}