package com.example.taskmanagementsystem.strategy

import strategy.PriorityStrategy

class MediumPriorityStrategy : PriorityStrategy {

    override fun calculatePriority(daysLeft: Int): String {
        return "Medium"
    }

}