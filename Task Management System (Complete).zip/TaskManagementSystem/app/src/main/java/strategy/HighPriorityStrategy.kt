package com.example.taskmanagementsystem.strategy

import strategy.PriorityStrategy

class HighPriorityStrategy : PriorityStrategy {

    override fun calculatePriority(daysLeft: Int): String {
        return "High"
    }

}