package strategy

interface PriorityStrategy {

    fun calculatePriority(daysLeft: Int): String

}