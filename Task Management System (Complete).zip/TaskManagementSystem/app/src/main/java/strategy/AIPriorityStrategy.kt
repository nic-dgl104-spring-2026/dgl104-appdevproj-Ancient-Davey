package com.example.taskmanagementsystem.strategy

import strategy.PriorityStrategy

class AIPriorityStrategy : PriorityStrategy {

    override fun calculatePriority(daysLeft: Int): String {

        return when {
            daysLeft <= 1 -> "High"
            daysLeft <= 5 -> "Medium"
            else -> "Low"
        }

    }

}