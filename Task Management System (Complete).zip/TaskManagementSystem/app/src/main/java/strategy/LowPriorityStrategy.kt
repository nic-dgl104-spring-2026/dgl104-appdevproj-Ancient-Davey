package com.example.taskmanagementsystem.strategy

import strategy.PriorityStrategy

class LowPriorityStrategy : PriorityStrategy {

    override fun calculatePriority(daysLeft: Int): String {
        return "Low"
    }

}