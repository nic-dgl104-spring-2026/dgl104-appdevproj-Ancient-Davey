
package com.example.taskmanagementsystem.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.taskmanagementsystem.R
import com.example.taskmanagementsystem.models.Task

class TaskAdapter(

    private var tasks: MutableList<Task>,

    private val onEdit: (Task) -> Unit,

    private val onDelete: (Task) -> Unit

) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val title: TextView =
            itemView.findViewById(R.id.taskTitle)

        val description: TextView =
            itemView.findViewById(R.id.taskDescription)

        val priority: TextView =
            itemView.findViewById(R.id.taskPriority)

        val status: TextView =
            itemView.findViewById(R.id.taskStatus)

        val dueDate: TextView =
            itemView.findViewById(R.id.taskDueDate)

        val editButton: Button =
            itemView.findViewById(R.id.editButton)

        val deleteButton: Button =
            itemView.findViewById(R.id.deleteButton)

    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): TaskViewHolder {

        val view = LayoutInflater
            .from(parent.context)
            .inflate(
                R.layout.item_task,
                parent,
                false
            )

        return TaskViewHolder(view)

    }

    override fun onBindViewHolder(
        holder: TaskViewHolder,
        position: Int
    ) {

        val task = tasks[position]

        holder.title.text = task.title

        holder.description.text = task.description

        holder.priority.text = "Priority: ${task.priority}"

        holder.status.text = "Status: ${task.status}"

        holder.dueDate.text = "Due: ${task.dueDate}"

        holder.editButton.setOnClickListener {

            onEdit(task)

        }

        holder.deleteButton.setOnClickListener {

            onDelete(task)

        }

    }

    override fun getItemCount(): Int {

        return tasks.size

    }

    fun updateList(newTasks: List<Task>) {

        tasks.clear()

        tasks.addAll(newTasks)

        notifyItemRangeChanged(0, tasks.size)

        notifyDataSetChanged()

    }

}